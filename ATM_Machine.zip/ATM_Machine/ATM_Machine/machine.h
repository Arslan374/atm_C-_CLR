#include<string.h>
#include<iostream>
#include<fstream>
using namespace std;
using namespace System;

char fname[15],balance[15],w_amount[15],amt[15],acno[15],pin[15],ac_no[15],_pin[15],f_name[15];

bool ulogin(System::String^ aacno,System::String^ apin){
ifstream fg;
	fg.open("accounts.txt");
while(fg>>acno>>pin>>fname>>amt)
	{
System::String^  a=gcnew String(acno);
    	if(aacno==a)
    	{System::String^  b=gcnew String(pin);
			if(apin==b)
			{
			/*strcpy_s(ac_no,acno);
			strcpy_s(_pin,pin);
			strcpy_s(balance,amt);
			strcpy_s(f_name,fname);*/
			fg.close();
			return 0;
			}
		}
	}
fg.close();
return 1;}
/*bool withdraw(int cash){
	if(cash>balance){
		return 1;}
	else
	{balance=balance-cash;
	fstream fg;
	fg.open("accounts.txt",ios::in|ios::out);
while(fg>>acno>>pin>>fname>>amt)
	{

    	if(ac_no==acno)
    	{fg<<ac_no<<_pin<<f_name<<balance<<"\n";
		fg.close();
		return 0;}}
	}
return 1;}*/

